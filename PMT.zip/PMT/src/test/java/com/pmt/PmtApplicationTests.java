package com.pmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
