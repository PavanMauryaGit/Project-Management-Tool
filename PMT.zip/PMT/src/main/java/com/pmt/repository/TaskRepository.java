package com.pmt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pmt.entities.Project;
import com.pmt.entities.Task;

import jakarta.transaction.Transactional;
@Repository
public interface TaskRepository extends JpaRepository<Task,Long>{
	@Query("SELECT t FROM Task t JOIN FETCH t.assignedTo WHERE t.createdBy.id = :id")
	List<Task> findAllByCreatedById(Long id);

	@Query("SELECT t FROM Task t WHERE t.assignedTo.id = :userId")
	List<Task> findTasksAssignedToUser(@Param("userId") long userId);

	@Modifying
    @Transactional
    @Query("UPDATE Task t SET t.status = :status WHERE t.taskID = :taskID")
    void updateTaskStatus(Long taskID, String status);
	
	
	@Query("SELECT t.assignedTo.userName, COUNT(DISTINCT t.project.projectID) " +
		       "FROM Task t WHERE t.project.createdBy.id = :createdById " +
		       "AND t.assignedTo IS NOT NULL GROUP BY t.assignedTo.userName")
    List<Object[]> getAssignedProjectsUserWise(@Param("createdById") long createdById);
    
    @Query("SELECT t.assignedTo.userName, COUNT(t) " +
    	       "FROM Task t " +
    	       "WHERE t.project.createdBy.id = :createdById " +
    	       "AND t.assignedTo IS NOT NULL " +
    	       "GROUP BY t.assignedTo.userName")
	List<Object[]> getTasksAssignedToUsers(@Param("createdById") long createdById);
	
	@Query("SELECT t.status, COUNT(t) FROM Task t WHERE t.createdBy.id = :userId GROUP BY t.status")
	List<Object[]> getTaskStatusCountByCreator(@Param("userId") long userId);
	
	@Query("SELECT t.priority, COUNT(t) FROM Task t WHERE t.createdBy.id = :userId GROUP BY t.priority")
	List<Object[]> getTaskCountByPriority(@Param("userId") long userId);
}
