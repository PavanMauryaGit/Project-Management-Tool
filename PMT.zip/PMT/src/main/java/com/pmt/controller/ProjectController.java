package com.pmt.controller;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.pmt.entities.Project;
import com.pmt.entities.User;
import com.pmt.security.JwtHelper;
import com.pmt.services.ProjectService;
import com.pmt.services.UserService;

import jakarta.servlet.http.HttpServletRequest;

@RestController

@RequestMapping("/projects")
public class ProjectController {

	@Autowired
	private ProjectService projectService;
	
	@Autowired
	private JwtHelper jwtHelper;
	
	@Autowired
	private UserService userService;
	
	@PostMapping
	public ResponseEntity<?> createProject(@RequestBody Project project,HttpServletRequest request)
	{
		try {
			String requestHeader = request.getHeader("Authorization");

	        String userName = null;
	        String token = null;
	        if (requestHeader != null && requestHeader.startsWith("Bearer")) 
	        {
	        
	            token = requestHeader.substring(7);
	        }
			 userName = jwtHelper.getUsernameFromToken(token);
			System.out.println("userName::::::"+userName);
			User user = userService.loadUserByUsername(userName);
			project.setCreatedBy(user);
			project.setCreateDate(new Date());
			if(project.getProjectID() != 0){	
				project.setUpdatedDate(new Date());
			}
			projectService.createProject(project);
            return new ResponseEntity<>("Product added successfully!", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error adding product: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
		
	}
	@GetMapping("/{projectID}")
	public ResponseEntity<Project> getProjectByID(@PathVariable long projectID)
	{
		Project list = projectService.project(projectID);
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	@GetMapping
	public ResponseEntity<List<Project>> getAllProjects(HttpServletRequest request)
	{
		User user =null;
		List<Project> list =null;
		try {
			String token = null;
			String userName= null;
			String requestHeader = request.getHeader("Authorization");
			if (requestHeader != null && requestHeader.startsWith("Bearer")) 
	        {
	            token = requestHeader.substring(7);
	        }
			 userName = jwtHelper.getUsernameFromToken(token);
			System.out.println("userName::::::"+userName);
			user = userService.loadUserByUsername(userName);
			System.out.println("================"+user.getId()+" "+user.getUserName());
			list = projectService.allProject(user.getId());
			System.out.println("List======"+list);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok(list);
		
	}
	@DeleteMapping("/{projectID}")
	public ResponseEntity<String> deleteProject(@PathVariable long projectID)
	{
		projectService.deletedProject(projectID);
		return ResponseEntity.status(HttpStatus.OK).body("Project deleted successfully");
	}
	@GetMapping("/export")
    public ResponseEntity<byte[]> exportProjects(HttpServletRequest request) {
    	User user =null;
		List<Project> list =null;
    	String token = null;
		String userName= null;
		String requestHeader = request.getHeader("Authorization");
		if (requestHeader != null && requestHeader.startsWith("Bearer")) 
        {
            token = requestHeader.substring(7);
        }
		 userName = jwtHelper.getUsernameFromToken(token);
		user = userService.loadUserByUsername(userName);
    	
        ByteArrayOutputStream  outputStream = projectService.exportProjectsToExcel(user.getId());
        if (outputStream != null) {
            byte[] bytes = outputStream.toByteArray();
            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Disposition", "attachment; filename=projects.xlsx");
            return new ResponseEntity<>(bytes, headers, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
