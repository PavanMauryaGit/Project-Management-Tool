package com.pmt.controller;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pmt.dto.TaskDTO;
import com.pmt.entities.Project;
import com.pmt.entities.Task;
import com.pmt.entities.User;
import com.pmt.security.JwtHelper;
import com.pmt.services.ProjectService;
import com.pmt.services.TaskService;
import com.pmt.services.UserService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/tasks")
public class TaskController {
	
	@Autowired
	private JwtHelper jwtHelper;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private TaskService taskService;
	
	@Autowired
	private ProjectService projectService;

	private Task task2;
	
	@PostMapping
	public ResponseEntity<?> createProject(@RequestBody TaskDTO taskdto,HttpServletRequest request)
	{
		System.out.println("test test");
		try {
			String requestHeader = request.getHeader("Authorization");

	        String userName = null;
	        String token = null;
	        if (requestHeader != null && requestHeader.startsWith("Bearer")) 
	        {
	        
	            token = requestHeader.substring(7);
	        }
			 userName = jwtHelper.getUsernameFromToken(token);
			User user = userService.loadUserByUsername(userName);
			Task task = new Task();
			task.setName(taskdto.getName());
			task.setDescription(taskdto.getDescription());
			task.setStartDate(taskdto.getStartDate());
			task.setEndDate(taskdto.getEndDate());
			task.setStatus(taskdto.getStatus());
			task.setPriority(taskdto.getPriority());
			task.setCreatedBy(user);
			task.setCreatedAt(new Date());
			User assignedUser = userService.getUserByUserID(taskdto.getAssignedTo());
			Project assignedProject = projectService.project(taskdto.getProjectID());
			System.out.println("assigned user"+assignedUser);
			System.out.println("assigned project"+assignedProject);
			task.setProject(assignedProject);
			task.setAssignedTo(assignedUser);
			
			if(taskdto.getTaskID() != 0){	
				task.setTaskID(taskdto.getTaskID());
				task.setUpdatedAt(new Date());
			}
			task2 = taskService.createTask(task);
			
			
            return new ResponseEntity<>("task added successfully!", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error adding product: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
		
	}
	
	@GetMapping
	public ResponseEntity<List<TaskDTO>> getAllTasks(HttpServletRequest request)
	{
		User user =null;
		List<TaskDTO> list =null;
		try {
			String token = null;
			String userName= null;
			String requestHeader = request.getHeader("Authorization");
			if (requestHeader != null && requestHeader.startsWith("Bearer")) 
	        {
	            token = requestHeader.substring(7);
	        }
			 userName = jwtHelper.getUsernameFromToken(token);
			user = userService.loadUserByUsername(userName);
			list = taskService.allTask(user.getId());
			System.out.println("List======"+list);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok(list);
		
	}
	
	@DeleteMapping("/{taskID}")
	public ResponseEntity<String> deleteTask(@PathVariable long taskID)
	{
		taskService.deleteTask(taskID);
		return ResponseEntity.status(HttpStatus.OK).body("Task deleted successfully");
	}
	
	@GetMapping("/export")
    public ResponseEntity<byte[]> exportTasks(HttpServletRequest request) {
    	User user =null;
		List<Project> list =null;
    	String token = null;
		String userName= null;
		String requestHeader = request.getHeader("Authorization");
		if (requestHeader != null && requestHeader.startsWith("Bearer")) 
        {
            token = requestHeader.substring(7);
        }
		 userName = jwtHelper.getUsernameFromToken(token);
		user = userService.loadUserByUsername(userName);
    	
        ByteArrayOutputStream  outputStream = taskService.exportTasksToExcel(user.getId());
        if (outputStream != null) {
            byte[] bytes = outputStream.toByteArray();
            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Disposition", "attachment; filename=Tasks.xlsx");
            return new ResponseEntity<>(bytes, headers, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	
}
