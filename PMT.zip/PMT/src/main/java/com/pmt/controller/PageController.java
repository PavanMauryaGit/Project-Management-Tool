package com.pmt.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pmt.entities.Project;
import com.pmt.entities.User;
import com.pmt.security.JwtHelper;
import com.pmt.services.ProjectService;
import com.pmt.services.UserService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class PageController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	@Autowired
	private ProjectService projectService;
	
	@Autowired
	private JwtHelper jwtHelper;

	
	@GetMapping("/taskpage")
	public String showDashboard(@RequestParam("Authorization") String token,Model model,HttpServletRequest request) throws IOException
	{
		String decodedToken = new String(Base64.getDecoder().decode(token));
		
		System.out.println("dashboard:::::token :: "+decodedToken);
		String userName = jwtHelper.getUsernameFromToken(decodedToken);
		System.out.println("userName::::::"+userName);
		User user = userService.loadUserByUsername(userName);
		boolean validateToken =false;
		UserDetails userDetails = userDetailsService.loadUserByUsername(userName);
		validateToken = jwtHelper.validateToken(decodedToken, userDetails);
		if(validateToken)
		{
			System.out.println("token validated");
			String returnRoleWise="";
		    returnRoleWise = user.getRole().equals("ADMIN") ? "Admin Dashboard" : user.getRole().equals("USER") ? "User Dashboard" : "";
		 	model.addAttribute("userName",userName); 
		 	model.addAttribute("pageHeading", returnRoleWise);
		 	if(user.getRole().equals("ADMIN")) {
			 	List<User> asignToList = userService.allUser("USER");
			 	List<Project> projectList = projectService.allProject(user.getId());
			 	model.addAttribute("assignToList",asignToList);
			 	model.addAttribute("projectList",projectList);
			 	 model.addAttribute("title","PMT || Task List");
			 	return "taskList";
		 	}else if(user.getRole().equals("USER")) {
		 		 model.addAttribute("title","PMT || Task List");
		 		return "userTaskList";
		 	}
		 		
		}
		
		return "redirect:/login";
		 
		
	}

}
