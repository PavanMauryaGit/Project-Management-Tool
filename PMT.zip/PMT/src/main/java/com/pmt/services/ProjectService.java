package com.pmt.services;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pmt.dto.ProjectDTO;
import com.pmt.entities.Project;
import com.pmt.repository.ProjectRepository;

@Service
public class ProjectService {
	
	@Autowired
	private ProjectRepository projectRepository;
	
	public Project createProject(Project project)
	{
		return projectRepository.save(project);
	}
	
	public Project project(long projectID)
	{
		return projectRepository.findById(projectID).get();
	}
	
	public List<Project> allProject(long id)
	{
		return projectRepository.findAllByCreatedById(id);
	}
	public void deletedProject(long projectID)
	{
		projectRepository.deleteById(projectID);
	}
	
	public List<ProjectDTO> findProjectsAssignedToUser(long userID)
	{
		List<Project> projects = projectRepository.findProjectsAssignedToUser(userID);
		List<ProjectDTO> projectDTOs = new ArrayList<>();

	    for (Project project : projects) {
	        ProjectDTO projectDTO = new ProjectDTO();
	        projectDTO.setProjectID(project.getProjectID());
	        projectDTO.setProjectName(project.getProjectName());
	        projectDTO.setDescription(project.getDescription());
	        projectDTO.setStatus(project.getStatus());
	        projectDTO.setStartDate(project.getStartDate());
	        projectDTO.setEndDate(project.getEndDate());
	        
	        // Map tasks if needed

	        projectDTOs.add(projectDTO);
	    }
	    return projectDTOs;
	}

	public Map<String, Long> getProjectStatusCounts(Long userId) {
	    List<Object[]> results = projectRepository.getProjectStatusCountsByUser(userId);
	    Map<String, Long> statusCounts = new HashMap<>();
	    for (Object[] result : results) {
	        statusCounts.put((String) result[0], (Long) result[1]);
	    }
	    return statusCounts;
	}
	
	public ByteArrayOutputStream exportProjectsToExcel(long createdById) {
	    List<Project> projects = projectRepository.findAllByCreatedById(createdById);

	    try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
	        Sheet sheet = workbook.createSheet("Projects");

	        Font titleFont = workbook.createFont();
	        titleFont.setBold(true);
	        titleFont.setFontHeightInPoints((short) 16); // Set font size

	        CellStyle titleStyle = workbook.createCellStyle();
	        titleStyle.setFont(titleFont);
	        titleStyle.setAlignment(HorizontalAlignment.CENTER);
	        titleStyle.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
	        titleStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        Row titleRow = sheet.createRow(0);
	        Cell titleCell = titleRow.createCell(0);
	        titleCell.setCellValue("Project List");
	        titleCell.setCellStyle(titleStyle);
	        
	        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 4)); 

	        Font headerFont = workbook.createFont();
	        headerFont.setColor(IndexedColors.WHITE.getIndex());
	        headerFont.setBold(true);

	        CellStyle headerStyle = workbook.createCellStyle();
	        headerStyle.setFont(headerFont);
	        headerStyle.setFillForegroundColor(IndexedColors.BLACK.getIndex());
	        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	        
	        CellStyle dataStyle = workbook.createCellStyle();
	        dataStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
	        dataStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        Row headerRow = sheet.createRow(1); 
	        String[] headers = {"Project Name", "Description", "Start Date", "End Date", "Status"};
	        for (int i = 0; i < headers.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(headers[i]);
	            cell.setCellStyle(headerStyle);
	            sheet.setColumnWidth(i, 20 * 256); 
	        }

	        
	        int rowIndex = 2; 
	        for (Project project : projects) {
	            Row row = sheet.createRow(rowIndex++);
	            
	            row.createCell(0).setCellValue(project.getProjectName());
	            row.createCell(1).setCellValue(project.getDescription());
	            row.createCell(2).setCellValue(project.getStartDate().toString());
	            row.createCell(3).setCellValue(project.getEndDate().toString());
	            row.createCell(4).setCellValue(project.getStatus());
	            
	            
	            for (int i = 0; i < headers.length; i++) {
	                row.getCell(i).setCellStyle(dataStyle);
	            }
	        }

	        workbook.write(outputStream);
	        return outputStream;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}

}
