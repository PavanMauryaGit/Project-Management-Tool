package com.pmt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pmt.entities.User;
import com.pmt.repository.UserRepository;
@Service
public class UserService {
	
	@Autowired
	private UserRepository repository;
	
	public User registerUser(User user) {
		return repository.save(user);
	}

	public User loadUserByUsername(String userName) {
		return repository.loadUserByUsername(userName);
	}
	
	public List<User> allUser(String role)
	{
		return repository.getAllUser(role);
	}
	public User getUserByUserID(long id)
	{
		return repository.findById(id).get();
	}
}
