package com.pmt.services;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pmt.dto.TaskDTO;
import com.pmt.entities.Project;
import com.pmt.entities.Task;
import com.pmt.repository.TaskRepository;

@Service
public class TaskService {

	@Autowired
	private TaskRepository taskRepository;
	
	public Task createTask(Task task)
	{
		return taskRepository.save(task);
	}
	
	public Task getTaskByID(long taskID)
	{
		return taskRepository.findById(taskID).get();
	}
	
	public List<Task> getAllTask()
	{
		return taskRepository.findAll();
	}
	public void deleteTask(long taskID)
	{
		taskRepository.deleteById(taskID);
	}
	
	public Map<String, Long> getAssignedProjectsUserWise(long id) {
        List<Object[]> results = taskRepository.getAssignedProjectsUserWise(id);
        Map<String, Long> assignedProjects = new HashMap<>();

        for (Object[] result : results) {
            String userName = (String) result[0];
            Long projectCount = (Long) result[1];
            assignedProjects.put(userName, projectCount);
        }
        return assignedProjects;
    }
	
	public Map<String, Long> getTasksAssignedToUsers(long createdById) {
		
		List<Object[]> results = taskRepository.getTasksAssignedToUsers(createdById);
        Map<String, Long> assignedTasks = new HashMap<>();

        for (Object[] result : results) {
            String userName = (String) result[0];
            Long taskCount = (Long) result[1];
            assignedTasks.put(userName, taskCount);
        }
        return assignedTasks;
	}
	public Map<String, Long> getTaskStatusCount(long createdById) {
		
		List<Object[]> results = taskRepository.getTaskStatusCountByCreator(createdById);
        Map<String, Long> assignedTaskStatus = new HashMap<>();

        for (Object[] result : results) {
            String userName = (String) result[0];
            Long taskCount = (Long) result[1];
            assignedTaskStatus.put(userName, taskCount);
        }
        return assignedTaskStatus;
	}
	public Map<String, Long> getTaskCountByPriority(Long userId) {
	    List<Object[]> results = taskRepository.getTaskCountByPriority(userId);
	    Map<String, Long> priorityCounts = new HashMap<>();
	    for (Object[] result : results) {
	    	priorityCounts.put((String) result[0], (Long) result[1]);
	    }
	    return priorityCounts;
	}
	public List<TaskDTO> allTask(long id)
	{
		 List<Task> tasks = taskRepository.findAllByCreatedById(id);
		 List<TaskDTO> taskDTOs = new ArrayList<>();
		 for (Task task : tasks) {
		        TaskDTO dto = new TaskDTO();
		        dto.setTaskID(task.getTaskID());
		        dto.setName(task.getName());
		        dto.setDescription(task.getDescription());
		        dto.setStatus(task.getStatus());
		        dto.setPriority(task.getPriority());
		        dto.setStartDate(task.getStartDate());
		        dto.setEndDate(task.getEndDate());
		        
		        // Set assignedTo's username if not null
		        if (task.getAssignedTo() != null) {
		            dto.setAssignedToUserName(task.getAssignedTo().getUserName());
		            dto.setAssignedTo(task.getAssignedTo().getId());
		        } else {
		            dto.setAssignedToUserName("Unassigned");
		        }
		        
		        // Set project name if needed
		        if (task.getProject() != null) {
		            dto.setProjectName(task.getProject().getProjectName());
		            dto.setProjectID(task.getProject().getProjectID());
		        }

		        taskDTOs.add(dto);
		    }
		return taskDTOs;
	}

	public List<TaskDTO> findTasksAssignedToUser(long id) {
		
		List<Task> tasklist =taskRepository.findTasksAssignedToUser(id);
		List<TaskDTO> taskDTOs = new ArrayList<>();
		 for (Task task : tasklist) {
		        TaskDTO dto = new TaskDTO();
		        dto.setTaskID(task.getTaskID());
		        dto.setName(task.getName());
		        dto.setDescription(task.getDescription());
		        dto.setStatus(task.getStatus());
		        dto.setPriority(task.getPriority());
		        dto.setStartDate(task.getStartDate());
		        dto.setEndDate(task.getEndDate());
		        
		        // Set assignedTo's username if not null
		        if (task.getAssignedTo() != null) {
		            dto.setAssignedToUserName(task.getAssignedTo().getUserName());
		            dto.setAssignedTo(task.getAssignedTo().getId());
		        } else {
		            dto.setAssignedToUserName("Unassigned");
		        }
		        
		        // Set project name if needed
		        if (task.getProject() != null) {
		            dto.setProjectName(task.getProject().getProjectName());
		            dto.setProjectID(task.getProject().getProjectID());
		        }

		        taskDTOs.add(dto);
		 }
		return taskDTOs;
	}

	public void updateTaskStatus(TaskDTO taskDTO) {
        taskRepository.updateTaskStatus(taskDTO.getTaskID(), taskDTO.getStatus());
    }
	
	public ByteArrayOutputStream exportTasksToExcel(long createdById) {
	    List<Task> tasks = taskRepository.findAllByCreatedById(createdById);

	    try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
	        Sheet sheet = workbook.createSheet("Tasks");

	        // Create a title row
	        Font titleFont = workbook.createFont();
	        titleFont.setBold(true);
	        titleFont.setFontHeightInPoints((short) 16); // Set font size

	        CellStyle titleStyle = workbook.createCellStyle();
	        titleStyle.setFont(titleFont);
	        titleStyle.setAlignment(HorizontalAlignment.CENTER);
	        titleStyle.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
	        titleStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        Row titleRow = sheet.createRow(0);
	        Cell titleCell = titleRow.createCell(0);
	        titleCell.setCellValue("Task List");
	        titleCell.setCellStyle(titleStyle);

	        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 5)); // Merging title cells

	        // Create header row
	        Font headerFont = workbook.createFont();
	        headerFont.setColor(IndexedColors.WHITE.getIndex());
	        headerFont.setBold(true);

	        CellStyle headerStyle = workbook.createCellStyle();
	        headerStyle.setFont(headerFont);
	        headerStyle.setFillForegroundColor(IndexedColors.BLACK.getIndex());
	        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        CellStyle dataStyle = workbook.createCellStyle();
	        dataStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
	        dataStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        Row headerRow = sheet.createRow(1);
	        String[] headers = {"Task ID", "Name", "Description", "Status", "Priority", "Assigned To","Project", "Start Date", "End Date"};
	        for (int i = 0; i < headers.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(headers[i]);
	            cell.setCellStyle(headerStyle);
	            sheet.setColumnWidth(i, 20 * 256); // Set column width
	        }

	        // Populate data
	        int rowIndex = 2; // Starting row for data
	        for (Task task : tasks) {
	            Row row = sheet.createRow(rowIndex++);

	            row.createCell(0).setCellValue(task.getTaskID());
	            row.createCell(1).setCellValue(task.getName());
	            row.createCell(2).setCellValue(task.getDescription());
	            row.createCell(3).setCellValue(task.getStatus());
	            row.createCell(4).setCellValue(task.getPriority());
	            row.createCell(5).setCellValue(task.getAssignedTo() != null ? task.getAssignedTo().getUserName() : "Unassigned");
	            row.createCell(6).setCellValue(task.getProject() != null ? task.getProject().getProjectName() : "");
	            row.createCell(7).setCellValue(task.getStartDate().toString());
	            row.createCell(8).setCellValue(task.getEndDate().toString());

	            // Apply data style to all cells in the row
	            for (int i = 0; i < headers.length; i++) {
	                row.getCell(i).setCellStyle(dataStyle);
	            }
	        }

	        workbook.write(outputStream);
	        return outputStream;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}

}
